const API_BASE_URL = "http://localhost:5001/api";

export interface CurrentWeatherData {
  location: string;
  temperature: number;
  feels_like: number;
  condition: string;
  humidity: number;
  wind_speed: number;
  wind_direction: string;
  pressure: number;
  visibility: number;
  icon: string;
  latitude: number;
  longitude: number;
}

export interface ForecastDay {
  day: string;
  date: string;
  high: number;
  low: number;
  condition: string;
  icon: string;
}

export interface ForecastData {
  forecast: ForecastDay[];
}

export interface WeatherSearch {
  id: string;
  location: string;
  latitude?: number;
  longitude?: number;
  start_date: string;
  end_date: string;
  avg_temp: number;
  min_temp: number;
  max_temp: number;
  created_at?: string;
  updated_at?: string;
}

export interface WeatherSearchCreate {
  location: string;
  start_date: string;
  end_date: string;
  avg_temp: number;
  min_temp: number;
  max_temp: number;
}

export const weatherApi = {
  async getCurrentWeather(location: string): Promise<CurrentWeatherData> {
    const response = await fetch(
      `${API_BASE_URL}/weather/current?location=${encodeURIComponent(location)}`
    );
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || "Failed to fetch weather");
    }
    return response.json();
  },

  async getForecast(location: string): Promise<ForecastData> {
    const response = await fetch(
      `${API_BASE_URL}/weather/forecast?location=${encodeURIComponent(location)}`
    );
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || "Failed to fetch forecast");
    }
    return response.json();
  },

  async getSearches(): Promise<WeatherSearch[]> {
    const response = await fetch(`${API_BASE_URL}/weather-searches`);
    if (!response.ok) {
      throw new Error("Failed to fetch searches");
    }
    return response.json();
  },

  async createSearch(data: WeatherSearchCreate): Promise<WeatherSearch> {
    const response = await fetch(`${API_BASE_URL}/weather-searches`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || "Failed to create search");
    }
    return response.json();
  },

  async updateSearch(id: string, data: Partial<WeatherSearchCreate>): Promise<WeatherSearch> {
    const response = await fetch(`${API_BASE_URL}/weather-searches/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || "Failed to update search");
    }
    return response.json();
  },

  async deleteSearch(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/weather-searches/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) {
      throw new Error("Failed to delete search");
    }
  },

  async exportData(format: "json" | "csv" | "xml" | "markdown"): Promise<Blob> {
    const response = await fetch(`${API_BASE_URL}/export/${format}`);
    if (!response.ok) {
      throw new Error(`Failed to export as ${format}`);
    }
    return response.blob();
  },
};
