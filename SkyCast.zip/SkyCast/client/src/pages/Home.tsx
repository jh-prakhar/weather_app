import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import WeatherSearch from "@/components/WeatherSearch";
import CurrentWeather from "@/components/CurrentWeather";
import ForecastGrid from "@/components/ForecastGrid";
import SavedSearches, { type SavedSearch } from "@/components/SavedSearches";
import SavedSearchForm from "@/components/SavedSearchForm";
import DeleteConfirmation from "@/components/DeleteConfirmation";
import ThemeToggle from "@/components/ThemeToggle";
import { useToast } from "@/hooks/use-toast";
import { weatherApi, type CurrentWeatherData, type ForecastDay } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Home() {
  const { toast } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [editData, setEditData] = useState<SavedSearch | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<string>("");
  const [currentWeather, setCurrentWeather] = useState<CurrentWeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastDay[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  // Query for saved searches
  const { data: savedSearches = [], refetch: refetchSearches } = useQuery({
    queryKey: ["/api/weather-searches"],
    queryFn: weatherApi.getSearches,
  });

  const handleSearch = async (location: string) => {
    setSearchLoading(true);
    setCurrentLocation(location);
    
    try {
      const [weatherData, forecastData] = await Promise.all([
        weatherApi.getCurrentWeather(location),
        weatherApi.getForecast(location)
      ]);
      
      setCurrentWeather(weatherData);
      setForecast(forecastData.forecast);
      
      toast({
        title: "Weather Updated",
        description: `Showing weather for ${weatherData.location}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch weather",
        variant: "destructive",
      });
    } finally {
      setSearchLoading(false);
    }
  };

  const handleUseCurrentLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          const coordString = `${latitude.toFixed(4)},${longitude.toFixed(4)}`;
          await handleSearch(coordString);
        },
        (error) => {
          toast({
            title: "Location Error",
            description: "Could not access your location. Please check permissions.",
            variant: "destructive",
          });
        }
      );
    } else {
      toast({
        title: "Not Supported",
        description: "Geolocation is not supported by your browser.",
        variant: "destructive",
      });
    }
  };

  const createMutation = useMutation({
    mutationFn: weatherApi.createSearch,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weather-searches"] });
      toast({
        title: "Search Saved",
        description: "The weather search has been saved.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save search",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => weatherApi.updateSearch(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weather-searches"] });
      toast({
        title: "Search Updated",
        description: "The weather search has been updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update search",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: weatherApi.deleteSearch,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/weather-searches"] });
      toast({
        title: "Search Deleted",
        description: "The weather search has been removed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete search",
        variant: "destructive",
      });
    },
  });

  const handleAddSearch = () => {
    setEditData(null);
    setFormOpen(true);
  };

  const handleEditSearch = (search: SavedSearch) => {
    setEditData(search);
    setFormOpen(true);
  };

  const handleDeleteSearch = (id: string) => {
    setDeleteId(id);
    setDeleteOpen(true);
  };

  const handleConfirmDelete = () => {
    if (deleteId) {
      deleteMutation.mutate(deleteId);
      setDeleteId(null);
      setDeleteOpen(false);
    }
  };

  const handleSaveSearch = (data: Omit<SavedSearch, "id">) => {
    if (editData) {
      updateMutation.mutate({ 
        id: editData.id, 
        data: {
          location: data.location,
          start_date: data.startDate,
          end_date: data.endDate,
          avg_temp: data.avgTemp,
          min_temp: data.minTemp,
          max_temp: data.maxTemp,
        }
      });
    } else {
      createMutation.mutate({
        location: data.location,
        start_date: data.startDate,
        end_date: data.endDate,
        avg_temp: data.avgTemp,
        min_temp: data.minTemp,
        max_temp: data.maxTemp,
      });
    }
  };

  const handleExport = async (format: "json" | "csv" | "xml" | "markdown") => {
    try {
      const blob = await weatherApi.exportData(format);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `weather_searches.${format === "markdown" ? "md" : format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Export Successful",
        description: `Data exported as ${format.toUpperCase()}`,
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Could not export data",
        variant: "destructive",
      });
    }
  };

  const deleteSearchName = deleteId 
    ? savedSearches.find((s) => s.id === deleteId)?.location || ""
    : "";

  // Convert API format to component format
  const convertedSearches: SavedSearch[] = savedSearches.map((s) => ({
    id: s.id,
    location: s.location,
    startDate: s.start_date,
    endDate: s.end_date,
    avgTemp: s.avg_temp,
    minTemp: s.min_temp,
    maxTemp: s.max_temp,
  }));

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 z-50 bg-background">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <h1 className="text-2xl font-medium">Weather App</h1>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-12">
        <section>
          <WeatherSearch
            onSearch={handleSearch}
            onUseCurrentLocation={handleUseCurrentLocation}
            isLoading={searchLoading}
          />
        </section>

        {currentWeather && (
          <section>
            <CurrentWeather
              location={currentWeather.location}
              temperature={currentWeather.temperature}
              feelsLike={currentWeather.feels_like}
              condition={currentWeather.condition}
              humidity={currentWeather.humidity}
              windSpeed={currentWeather.wind_speed}
              windDirection={currentWeather.wind_direction}
              pressure={currentWeather.pressure}
              visibility={currentWeather.visibility}
              icon={currentWeather.icon}
            />
          </section>
        )}

        {forecast.length > 0 && (
          <section>
            <ForecastGrid forecast={forecast} />
          </section>
        )}

        <section>
          <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
            <h3 className="text-xl font-medium">Saved Weather Searches</h3>
            <div className="flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" data-testid="button-export">
                    <Download className="w-4 h-4 mr-2" />
                    Export Data
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => handleExport("json")}>
                    JSON
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleExport("csv")}>
                    CSV
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleExport("xml")}>
                    XML
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleExport("markdown")}>
                    Markdown
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          <SavedSearches
            searches={convertedSearches}
            onAdd={handleAddSearch}
            onEdit={handleEditSearch}
            onDelete={handleDeleteSearch}
          />
        </section>
      </main>

      <SavedSearchForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        onSave={handleSaveSearch}
        editData={editData}
      />

      <DeleteConfirmation
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleConfirmDelete}
        itemName={deleteSearchName}
      />
    </div>
  );
}
