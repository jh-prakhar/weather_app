import WeatherSearch from "../WeatherSearch";

export default function WeatherSearchExample() {
  return (
    <WeatherSearch
      onSearch={(location) => console.log("Search for:", location)}
      onUseCurrentLocation={() => console.log("Use current location")}
    />
  );
}
