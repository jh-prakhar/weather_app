import ForecastCard from "../ForecastCard";

export default function ForecastCardExample() {
  return (
    <ForecastCard
      day="Monday"
      date="Dec 30"
      high={72}
      low={58}
      condition="sunny"
      icon="clear"
    />
  );
}
