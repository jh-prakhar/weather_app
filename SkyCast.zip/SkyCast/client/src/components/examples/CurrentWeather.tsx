import CurrentWeather from "../CurrentWeather";

export default function CurrentWeatherExample() {
  return (
    <CurrentWeather
      location="San Francisco, CA"
      temperature={68}
      feelsLike={65}
      condition="partly cloudy"
      humidity={72}
      windSpeed={12}
      windDirection="NW"
      pressure={1013}
      visibility={10}
      icon="clouds"
    />
  );
}
