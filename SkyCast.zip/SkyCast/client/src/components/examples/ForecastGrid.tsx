import ForecastGrid from "../ForecastGrid";

export default function ForecastGridExample() {
  const mockForecast = [
    { day: "Monday", date: "Dec 30", high: 72, low: 58, condition: "sunny", icon: "clear" },
    { day: "Tuesday", date: "Dec 31", high: 68, low: 55, condition: "partly cloudy", icon: "clouds" },
    { day: "Wednesday", date: "Jan 1", high: 65, low: 52, condition: "rainy", icon: "rain" },
    { day: "Thursday", date: "Jan 2", high: 70, low: 56, condition: "cloudy", icon: "clouds" },
    { day: "Friday", date: "Jan 3", high: 74, low: 60, condition: "sunny", icon: "clear" },
  ];

  return <ForecastGrid forecast={mockForecast} />;
}
