import { useState } from "react";
import DeleteConfirmation from "../DeleteConfirmation";
import { Button } from "@/components/ui/button";

export default function DeleteConfirmationExample() {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <Button variant="destructive" onClick={() => setOpen(true)}>
        Open Delete Dialog
      </Button>
      <DeleteConfirmation
        open={open}
        onClose={() => setOpen(false)}
        onConfirm={() => {
          console.log("Confirmed delete");
          setOpen(false);
        }}
        itemName="New York, NY"
      />
    </div>
  );
}
