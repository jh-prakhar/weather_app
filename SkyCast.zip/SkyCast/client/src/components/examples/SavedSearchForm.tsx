import { useState } from "react";
import SavedSearchForm from "../SavedSearchForm";
import { Button } from "@/components/ui/button";

export default function SavedSearchFormExample() {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open Form</Button>
      <SavedSearchForm
        open={open}
        onClose={() => setOpen(false)}
        onSave={(data) => {
          console.log("Save:", data);
          setOpen(false);
        }}
      />
    </div>
  );
}
