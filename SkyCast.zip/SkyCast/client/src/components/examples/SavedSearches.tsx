import SavedSearches from "../SavedSearches";

export default function SavedSearchesExample() {
  const mockSearches = [
    {
      id: "1",
      location: "New York, NY",
      startDate: "2024-01-01",
      endDate: "2024-01-07",
      avgTemp: 42,
      minTemp: 35,
      maxTemp: 48,
    },
    {
      id: "2",
      location: "Miami, FL",
      startDate: "2024-01-15",
      endDate: "2024-01-22",
      avgTemp: 75,
      minTemp: 68,
      maxTemp: 82,
    },
  ];

  return (
    <SavedSearches
      searches={mockSearches}
      onAdd={() => console.log("Add new search")}
      onEdit={(search) => console.log("Edit search:", search)}
      onDelete={(id) => console.log("Delete search:", id)}
    />
  );
}
