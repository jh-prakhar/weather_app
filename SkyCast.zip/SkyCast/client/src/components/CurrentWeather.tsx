import { Card } from "@/components/ui/card";
import { 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  Sun, 
  CloudDrizzle,
  Wind,
  Droplets,
  Gauge,
  Eye,
  Thermometer
} from "lucide-react";

interface CurrentWeatherProps {
  location: string;
  temperature: number;
  feelsLike: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  windDirection: string;
  pressure: number;
  visibility: number;
  icon: string;
}

const weatherIcons: Record<string, typeof Sun> = {
  clear: Sun,
  clouds: Cloud,
  rain: CloudRain,
  drizzle: CloudDrizzle,
  snow: CloudSnow,
};

export default function CurrentWeather({
  location,
  temperature,
  feelsLike,
  condition,
  humidity,
  windSpeed,
  windDirection,
  pressure,
  visibility,
  icon,
}: CurrentWeatherProps) {
  const IconComponent = weatherIcons[icon] || Cloud;

  return (
    <div className="w-full max-w-4xl mx-auto">
      <h2 className="text-3xl font-normal mb-6" data-testid="text-location">{location}</h2>
      <Card className="p-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="flex flex-col items-center justify-center space-y-4">
            <IconComponent className="w-32 h-32 text-primary" />
            <div className="text-center">
              <div className="text-6xl font-bold" data-testid="text-temperature">
                {Math.round(temperature)}°
              </div>
              <div className="text-xl mt-2 text-muted-foreground capitalize" data-testid="text-condition">
                {condition}
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <Thermometer className="w-5 h-5 text-muted-foreground mt-1" />
              <div>
                <div className="text-sm font-medium text-muted-foreground">Feels Like</div>
                <div className="text-lg font-semibold" data-testid="text-feels-like">
                  {Math.round(feelsLike)}°
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Droplets className="w-5 h-5 text-muted-foreground mt-1" />
              <div>
                <div className="text-sm font-medium text-muted-foreground">Humidity</div>
                <div className="text-lg font-semibold" data-testid="text-humidity">
                  {humidity}%
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Wind className="w-5 h-5 text-muted-foreground mt-1" />
              <div>
                <div className="text-sm font-medium text-muted-foreground">Wind</div>
                <div className="text-lg font-semibold" data-testid="text-wind">
                  {windSpeed} mph {windDirection}
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Gauge className="w-5 h-5 text-muted-foreground mt-1" />
              <div>
                <div className="text-sm font-medium text-muted-foreground">Pressure</div>
                <div className="text-lg font-semibold" data-testid="text-pressure">
                  {pressure} mb
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3 col-span-2">
              <Eye className="w-5 h-5 text-muted-foreground mt-1" />
              <div>
                <div className="text-sm font-medium text-muted-foreground">Visibility</div>
                <div className="text-lg font-semibold" data-testid="text-visibility">
                  {visibility} miles
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
