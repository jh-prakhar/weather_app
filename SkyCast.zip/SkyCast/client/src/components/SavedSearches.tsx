import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Edit, Trash2 } from "lucide-react";

export interface SavedSearch {
  id: string;
  location: string;
  startDate: string;
  endDate: string;
  avgTemp: number;
  minTemp: number;
  maxTemp: number;
}

interface SavedSearchesProps {
  searches: SavedSearch[];
  onAdd: () => void;
  onEdit: (search: SavedSearch) => void;
  onDelete: (id: string) => void;
}

export default function SavedSearches({ searches, onAdd, onEdit, onDelete }: SavedSearchesProps) {
  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <h3 className="text-xl font-medium">Saved Weather Searches</h3>
        <Button onClick={onAdd} data-testid="button-add-search">
          <Plus className="w-4 h-4 mr-2" />
          Add New Search
        </Button>
      </div>

      {searches.length === 0 ? (
        <Card className="p-12">
          <div className="text-center text-muted-foreground">
            <p className="text-base">No saved searches yet.</p>
            <p className="text-sm mt-2">Click "Add New Search" to save a weather query.</p>
          </div>
        </Card>
      ) : (
        <>
          <div className="hidden md:block">
            <Card className="overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left text-xs font-semibold uppercase tracking-wider px-6 py-3">
                      Location
                    </th>
                    <th className="text-left text-xs font-semibold uppercase tracking-wider px-6 py-3">
                      Date Range
                    </th>
                    <th className="text-left text-xs font-semibold uppercase tracking-wider px-6 py-3">
                      Temperature
                    </th>
                    <th className="text-right text-xs font-semibold uppercase tracking-wider px-6 py-3">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {searches.map((search) => (
                    <tr key={search.id} className="hover-elevate" data-testid={`row-search-${search.id}`}>
                      <td className="px-6 py-4 text-sm font-medium" data-testid="text-search-location">
                        {search.location}
                      </td>
                      <td className="px-6 py-4 text-sm text-muted-foreground" data-testid="text-search-dates">
                        {search.startDate} to {search.endDate}
                      </td>
                      <td className="px-6 py-4 text-sm" data-testid="text-search-temp">
                        Avg: {Math.round(search.avgTemp)}° (Low: {Math.round(search.minTemp)}°, High: {Math.round(search.maxTemp)}°)
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex gap-2 justify-end">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => onEdit(search)}
                            data-testid={`button-edit-${search.id}`}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => onDelete(search.id)}
                            data-testid={`button-delete-${search.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>

          <div className="md:hidden space-y-4">
            {searches.map((search) => (
              <Card key={search.id} className="p-4" data-testid={`card-search-${search.id}`}>
                <div className="space-y-3">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Location</div>
                    <div className="text-base font-semibold">{search.location}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Date Range</div>
                    <div className="text-sm">{search.startDate} to {search.endDate}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Temperature</div>
                    <div className="text-sm">
                      Avg: {Math.round(search.avgTemp)}° (Low: {Math.round(search.minTemp)}°, High: {Math.round(search.maxTemp)}°)
                    </div>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => onEdit(search)}
                      data-testid={`button-edit-mobile-${search.id}`}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => onDelete(search.id)}
                      data-testid={`button-delete-mobile-${search.id}`}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
