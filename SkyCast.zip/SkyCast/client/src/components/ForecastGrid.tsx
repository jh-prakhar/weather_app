import ForecastCard from "./ForecastCard";

interface ForecastDay {
  day: string;
  date: string;
  high: number;
  low: number;
  condition: string;
  icon: string;
}

interface ForecastGridProps {
  forecast: ForecastDay[];
}

export default function ForecastGrid({ forecast }: ForecastGridProps) {
  return (
    <div className="w-full max-w-6xl mx-auto">
      <h3 className="text-xl font-medium mb-6">5-Day Forecast</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {forecast.map((day, index) => (
          <ForecastCard key={index} {...day} />
        ))}
      </div>
    </div>
  );
}
