import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MapPin } from "lucide-react";

interface WeatherSearchProps {
  onSearch: (location: string) => void;
  onUseCurrentLocation: () => void;
  isLoading?: boolean;
}

export default function WeatherSearch({ onSearch, onUseCurrentLocation, isLoading }: WeatherSearchProps) {
  const [location, setLocation] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (location.trim()) {
      onSearch(location);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-4">
      <form onSubmit={handleSubmit} className="flex gap-2 flex-wrap">
        <Input
          type="search"
          placeholder="Enter city, zip code, coordinates, or landmark..."
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="flex-1 min-w-[250px] h-12 text-base"
          data-testid="input-location"
          disabled={isLoading}
        />
        <Button 
          type="submit" 
          className="h-12 px-6"
          disabled={isLoading || !location.trim()}
          data-testid="button-search"
        >
          <Search className="w-5 h-5 mr-2" />
          Search
        </Button>
        <Button
          type="button"
          variant="outline"
          className="h-12 px-6"
          onClick={onUseCurrentLocation}
          disabled={isLoading}
          data-testid="button-current-location"
        >
          <MapPin className="w-5 h-5 mr-2" />
          Use My Location
        </Button>
      </form>
      <p className="text-sm text-muted-foreground text-center">
        Accepts: City names, ZIP/Postal codes, GPS coordinates (lat,lon), or landmarks
      </p>
    </div>
  );
}
