import { Card } from "@/components/ui/card";
import { Cloud, CloudRain, CloudSnow, Sun, CloudDrizzle } from "lucide-react";

interface ForecastCardProps {
  day: string;
  date: string;
  high: number;
  low: number;
  condition: string;
  icon: string;
}

const weatherIcons: Record<string, typeof Sun> = {
  clear: Sun,
  clouds: Cloud,
  rain: CloudRain,
  drizzle: CloudDrizzle,
  snow: CloudSnow,
};

export default function ForecastCard({ day, date, high, low, condition, icon }: ForecastCardProps) {
  const IconComponent = weatherIcons[icon] || Cloud;

  return (
    <Card className="p-4 hover-elevate transition-all" data-testid={`card-forecast-${day.toLowerCase()}`}>
      <div className="flex flex-col items-center space-y-3">
        <div className="text-sm font-semibold" data-testid="text-day">{day}</div>
        <div className="text-xs text-muted-foreground" data-testid="text-date">{date}</div>
        <IconComponent className="w-16 h-16 text-primary" />
        <div className="text-lg font-semibold" data-testid="text-temps">
          {Math.round(high)}° / {Math.round(low)}°
        </div>
        <div className="text-xs text-center text-muted-foreground capitalize" data-testid="text-forecast-condition">
          {condition}
        </div>
      </div>
    </Card>
  );
}
