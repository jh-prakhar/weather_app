#!/bin/bash
export DATABASE_URL="${DATABASE_URL}"
export OPENWEATHER_API_KEY="${OPENWEATHER_API_KEY:-}"
cd /home/runner/${REPL_SLUG}
uvicorn python_backend.main:app --host 0.0.0.0 --port 5001 --reload
