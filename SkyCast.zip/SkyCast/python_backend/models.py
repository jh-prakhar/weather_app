from sqlalchemy import Column, String, Float, DateTime, JSON, Integer
from sqlalchemy.sql import func
from python_backend.database import Base
import uuid

class WeatherSearch(Base):
    __tablename__ = "weather_searches"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    location = Column(String, nullable=False, index=True)
    latitude = Column(Float)
    longitude = Column(Float)
    start_date = Column(String, nullable=False)
    end_date = Column(String, nullable=False)
    avg_temp = Column(Float, nullable=False)
    min_temp = Column(Float, nullable=False)
    max_temp = Column(Float, nullable=False)
    weather_data = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
