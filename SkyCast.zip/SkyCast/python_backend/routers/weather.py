from fastapi import APIRouter, HTTPException, Query
from python_backend.services.weather_service import weather_service
from python_backend.schemas import CurrentWeatherResponse, ForecastResponse

router = APIRouter()

@router.get("/weather/current", response_model=CurrentWeatherResponse)
async def get_current_weather(location: str = Query(..., description="City name, zip code, or coordinates (lat,lon)")):
    """Get current weather for a location."""
    try:
        return await weather_service.get_current_weather(location)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching weather: {str(e)}")

@router.get("/weather/forecast", response_model=ForecastResponse)
async def get_forecast(location: str = Query(..., description="City name, zip code, or coordinates (lat,lon)")):
    """Get 5-day forecast for a location."""
    try:
        return await weather_service.get_forecast(location)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching forecast: {str(e)}")
