from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse, Response
from sqlalchemy.orm import Session
from python_backend.database import get_db
from python_backend.models import WeatherSearch
import json
import csv
import io
from datetime import datetime

router = APIRouter()

@router.get("/export/json")
def export_json(db: Session = Depends(get_db)):
    """Export all weather searches as JSON."""
    searches = db.query(WeatherSearch).all()
    
    data = [
        {
            "id": s.id,
            "location": s.location,
            "latitude": s.latitude,
            "longitude": s.longitude,
            "start_date": s.start_date,
            "end_date": s.end_date,
            "avg_temp": s.avg_temp,
            "min_temp": s.min_temp,
            "max_temp": s.max_temp,
            "created_at": s.created_at.isoformat() if s.created_at is not None else None,
        }
        for s in searches
    ]
    
    json_str = json.dumps(data, indent=2)
    
    return Response(
        content=json_str,
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename=weather_searches_{datetime.now().strftime('%Y%m%d')}.json"}
    )

@router.get("/export/csv")
def export_csv(db: Session = Depends(get_db)):
    """Export all weather searches as CSV."""
    searches = db.query(WeatherSearch).all()
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow([
        "ID", "Location", "Latitude", "Longitude", 
        "Start Date", "End Date", 
        "Avg Temp", "Min Temp", "Max Temp", 
        "Created At"
    ])
    
    # Write data
    for s in searches:
        writer.writerow([
            s.id,
            s.location,
            s.latitude,
            s.longitude,
            s.start_date,
            s.end_date,
            s.avg_temp,
            s.min_temp,
            s.max_temp,
            s.created_at.isoformat() if s.created_at is not None else ""
        ])
    
    csv_data = output.getvalue()
    
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=weather_searches_{datetime.now().strftime('%Y%m%d')}.csv"}
    )

@router.get("/export/xml")
def export_xml(db: Session = Depends(get_db)):
    """Export all weather searches as XML."""
    searches = db.query(WeatherSearch).all()
    
    xml_lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<weather_searches>']
    
    for s in searches:
        xml_lines.append('  <search>')
        xml_lines.append(f'    <id>{s.id}</id>')
        xml_lines.append(f'    <location>{s.location}</location>')
        xml_lines.append(f'    <latitude>{s.latitude}</latitude>')
        xml_lines.append(f'    <longitude>{s.longitude}</longitude>')
        xml_lines.append(f'    <start_date>{s.start_date}</start_date>')
        xml_lines.append(f'    <end_date>{s.end_date}</end_date>')
        xml_lines.append(f'    <avg_temp>{s.avg_temp}</avg_temp>')
        xml_lines.append(f'    <min_temp>{s.min_temp}</min_temp>')
        xml_lines.append(f'    <max_temp>{s.max_temp}</max_temp>')
        xml_lines.append(f'    <created_at>{s.created_at.isoformat() if s.created_at is not None else ""}</created_at>')
        xml_lines.append('  </search>')
    
    xml_lines.append('</weather_searches>')
    xml_data = '\n'.join(xml_lines)
    
    return Response(
        content=xml_data,
        media_type="application/xml",
        headers={"Content-Disposition": f"attachment; filename=weather_searches_{datetime.now().strftime('%Y%m%d')}.xml"}
    )

@router.get("/export/markdown")
def export_markdown(db: Session = Depends(get_db)):
    """Export all weather searches as Markdown."""
    searches = db.query(WeatherSearch).all()
    
    md_lines = [
        "# Weather Searches Export",
        f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n",
        "| Location | Start Date | End Date | Avg Temp | Min Temp | Max Temp |",
        "|----------|------------|----------|----------|----------|----------|"
    ]
    
    for s in searches:
        md_lines.append(
            f"| {s.location} | {s.start_date} | {s.end_date} | "
            f"{s.avg_temp}°F | {s.min_temp}°F | {s.max_temp}°F |"
        )
    
    md_data = '\n'.join(md_lines)
    
    return Response(
        content=md_data,
        media_type="text/markdown",
        headers={"Content-Disposition": f"attachment; filename=weather_searches_{datetime.now().strftime('%Y%m%d')}.md"}
    )
