from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import List
from python_backend.database import get_db
from python_backend.models import WeatherSearch
from python_backend.schemas import WeatherSearchCreate, WeatherSearchUpdate, WeatherSearchResponse
from python_backend.services.weather_service import weather_service

router = APIRouter()

@router.post("/weather-searches", response_model=WeatherSearchResponse)
async def create_search(search: WeatherSearchCreate, db: Session = Depends(get_db)):
    """Create a new weather search record."""
    try:
        # Validate location exists
        geocode_result = await weather_service.geocode_location(search.location)
        if not geocode_result:
            raise HTTPException(status_code=400, detail=f"Invalid location: {search.location}")
        
        lat, lon, normalized_name = geocode_result
        
        # Create database record
        db_search = WeatherSearch(
            location=normalized_name,
            latitude=lat,
            longitude=lon,
            start_date=search.start_date,
            end_date=search.end_date,
            avg_temp=search.avg_temp,
            min_temp=search.min_temp,
            max_temp=search.max_temp,
            weather_data=None
        )
        
        db.add(db_search)
        db.commit()
        db.refresh(db_search)
        
        return db_search
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error creating search: {str(e)}")

@router.get("/weather-searches", response_model=List[WeatherSearchResponse])
def get_searches(db: Session = Depends(get_db)):
    """Get all weather search records."""
    searches = db.query(WeatherSearch).order_by(WeatherSearch.created_at.desc()).all()
    return searches

@router.get("/weather-searches/{search_id}", response_model=WeatherSearchResponse)
def get_search(search_id: str, db: Session = Depends(get_db)):
    """Get a specific weather search record."""
    search = db.query(WeatherSearch).filter(WeatherSearch.id == search_id).first()
    if not search:
        raise HTTPException(status_code=404, detail="Search not found")
    return search

@router.put("/weather-searches/{search_id}", response_model=WeatherSearchResponse)
async def update_search(search_id: str, search_update: WeatherSearchUpdate, db: Session = Depends(get_db)):
    """Update a weather search record."""
    db_search = db.query(WeatherSearch).filter(WeatherSearch.id == search_id).first()
    if not db_search:
        raise HTTPException(status_code=404, detail="Search not found")
    
    try:
        # Validate location if being updated
        if search_update.location:
            geocode_result = await weather_service.geocode_location(search_update.location)
            if not geocode_result:
                raise HTTPException(status_code=400, detail=f"Invalid location: {search_update.location}")
            
            lat, lon, normalized_name = geocode_result
            db_search.location = normalized_name
            db_search.latitude = lat
            db_search.longitude = lon
        
        # Update other fields
        if search_update.start_date is not None:
            db_search.start_date = search_update.start_date
        if search_update.end_date is not None:
            db_search.end_date = search_update.end_date
        if search_update.avg_temp is not None:
            db_search.avg_temp = search_update.avg_temp
        if search_update.min_temp is not None:
            db_search.min_temp = search_update.min_temp
        if search_update.max_temp is not None:
            db_search.max_temp = search_update.max_temp
        
        db.commit()
        db.refresh(db_search)
        
        return db_search
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating search: {str(e)}")

@router.delete("/weather-searches/{search_id}")
def delete_search(search_id: str, db: Session = Depends(get_db)):
    """Delete a weather search record."""
    db_search = db.query(WeatherSearch).filter(WeatherSearch.id == search_id).first()
    if not db_search:
        raise HTTPException(status_code=404, detail="Search not found")
    
    try:
        db.delete(db_search)
        db.commit()
        return {"message": "Search deleted successfully"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting search: {str(e)}")
