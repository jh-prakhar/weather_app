import httpx
from typing import Optional, Tuple
from datetime import datetime
from python_backend.config import get_settings
from python_backend.schemas import CurrentWeatherResponse, ForecastResponse, ForecastDay

settings = get_settings()

class WeatherService:
    BASE_URL = "https://api.openweathermap.org/data/2.5"
    GEO_URL = "https://api.openweathermap.org/geo/1.0"
    
    def __init__(self):
        self.api_key = settings.openweather_api_key
    
    async def geocode_location(self, location: str) -> Optional[Tuple[float, float, str]]:
        """Convert location string to coordinates and normalized name."""
        if not self.api_key:
            raise ValueError("OpenWeatherMap API key not configured")
        
        # Check if location is already coordinates (lat,lon)
        if "," in location:
            try:
                parts = location.split(",")
                lat = float(parts[0].strip())
                lon = float(parts[1].strip())
                return (lat, lon, f"{lat},{lon}")
            except (ValueError, IndexError):
                pass
        
        # Use geocoding API
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.GEO_URL}/direct",
                    params={
                        "q": location,
                        "limit": 1,
                        "appid": self.api_key
                    },
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json()
                
                if data:
                    result = data[0]
                    lat = result["lat"]
                    lon = result["lon"]
                    name = result.get("name", location)
                    state = result.get("state", "")
                    country = result.get("country", "")
                    
                    full_name = name
                    if state:
                        full_name += f", {state}"
                    if country:
                        full_name += f", {country}"
                    
                    return (lat, lon, full_name)
                
                return None
            except Exception as e:
                print(f"Geocoding error: {e}")
                return None
    
    async def get_current_weather(self, location: str) -> CurrentWeatherResponse:
        """Get current weather for a location."""
        if not self.api_key:
            raise ValueError("OpenWeatherMap API key not configured")
        
        geocode_result = await self.geocode_location(location)
        if not geocode_result:
            raise ValueError(f"Could not find location: {location}")
        
        lat, lon, normalized_name = geocode_result
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.BASE_URL}/weather",
                params={
                    "lat": lat,
                    "lon": lon,
                    "appid": self.api_key,
                    "units": "imperial"
                },
                timeout=10.0
            )
            response.raise_for_status()
            data = response.json()
            
            # Convert wind direction from degrees to cardinal
            wind_deg = data.get("wind", {}).get("deg", 0)
            directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
            wind_direction = directions[round(wind_deg / 45) % 8]
            
            # Map weather condition to icon
            weather_main = data.get("weather", [{}])[0].get("main", "").lower()
            icon_map = {
                "clear": "clear",
                "clouds": "clouds",
                "rain": "rain",
                "drizzle": "drizzle",
                "snow": "snow",
                "thunderstorm": "rain",
                "mist": "clouds",
                "fog": "clouds"
            }
            icon = icon_map.get(weather_main, "clouds")
            
            return CurrentWeatherResponse(
                location=normalized_name,
                temperature=data["main"]["temp"],
                feels_like=data["main"]["feels_like"],
                condition=data["weather"][0]["description"],
                humidity=data["main"]["humidity"],
                wind_speed=data["wind"]["speed"],
                wind_direction=wind_direction,
                pressure=data["main"]["pressure"],
                visibility=data.get("visibility", 10000) / 1609.34,  # meters to miles
                icon=icon,
                latitude=lat,
                longitude=lon
            )
    
    async def get_forecast(self, location: str) -> ForecastResponse:
        """Get 5-day forecast for a location."""
        if not self.api_key:
            raise ValueError("OpenWeatherMap API key not configured")
        
        geocode_result = await self.geocode_location(location)
        if not geocode_result:
            raise ValueError(f"Could not find location: {location}")
        
        lat, lon, _ = geocode_result
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.BASE_URL}/forecast",
                params={
                    "lat": lat,
                    "lon": lon,
                    "appid": self.api_key,
                    "units": "imperial"
                },
                timeout=10.0
            )
            response.raise_for_status()
            data = response.json()
            
            # Group forecasts by day
            daily_forecasts = {}
            for item in data["list"]:
                dt = datetime.fromtimestamp(item["dt"])
                date_key = dt.strftime("%Y-%m-%d")
                
                if date_key not in daily_forecasts:
                    daily_forecasts[date_key] = {
                        "temps": [],
                        "conditions": [],
                        "dt": dt
                    }
                
                daily_forecasts[date_key]["temps"].append(item["main"]["temp"])
                daily_forecasts[date_key]["conditions"].append(
                    item["weather"][0]["main"].lower()
                )
            
            # Convert to forecast days (take first 5)
            forecast_days = []
            icon_map = {
                "clear": "clear",
                "clouds": "clouds",
                "rain": "rain",
                "drizzle": "drizzle",
                "snow": "snow"
            }
            
            for date_key in sorted(daily_forecasts.keys())[:5]:
                day_data = daily_forecasts[date_key]
                dt = day_data["dt"]
                temps = day_data["temps"]
                
                # Most common condition for the day
                condition = max(set(day_data["conditions"]), 
                              key=day_data["conditions"].count)
                
                forecast_days.append(ForecastDay(
                    day=dt.strftime("%A"),
                    date=dt.strftime("%b %d"),
                    high=max(temps),
                    low=min(temps),
                    condition=condition,
                    icon=icon_map.get(condition, "clouds")
                ))
            
            return ForecastResponse(forecast=forecast_days)

weather_service = WeatherService()
