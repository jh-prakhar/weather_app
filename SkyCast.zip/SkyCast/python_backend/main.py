from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from python_backend.routers import weather, searches, export
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create database tables on startup
    from python_backend.database import engine, Base
    try:
        Base.metadata.create_all(bind=engine)
    except Exception as e:
        print(f"Warning: Could not create tables: {e}")
    yield

app = FastAPI(title="Weather API", version="1.0.0", lifespan=lifespan)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(weather.router, prefix="/api", tags=["weather"])
app.include_router(searches.router, prefix="/api", tags=["searches"])
app.include_router(export.router, prefix="/api", tags=["export"])

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "service": "weather-api"}
