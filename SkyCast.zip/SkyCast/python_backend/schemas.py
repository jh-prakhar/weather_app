from pydantic import BaseModel, field_validator
from typing import Optional, Any
from datetime import datetime

class WeatherSearchBase(BaseModel):
    location: str
    start_date: str
    end_date: str
    avg_temp: float
    min_temp: float
    max_temp: float
    
    @field_validator('start_date', 'end_date')
    @classmethod
    def validate_date_format(cls, v):
        try:
            datetime.strptime(v, '%Y-%m-%d')
            return v
        except ValueError:
            raise ValueError('Date must be in YYYY-MM-DD format')
    
    @field_validator('end_date')
    @classmethod
    def validate_date_range(cls, v, info):
        if 'start_date' in info.data:
            start = datetime.strptime(info.data['start_date'], '%Y-%m-%d')
            end = datetime.strptime(v, '%Y-%m-%d')
            if end < start:
                raise ValueError('End date must be after start date')
        return v

class WeatherSearchCreate(WeatherSearchBase):
    pass

class WeatherSearchUpdate(BaseModel):
    location: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    avg_temp: Optional[float] = None
    min_temp: Optional[float] = None
    max_temp: Optional[float] = None
    
    @field_validator('start_date', 'end_date')
    @classmethod
    def validate_date_format(cls, v):
        if v is not None:
            try:
                datetime.strptime(v, '%Y-%m-%d')
                return v
            except ValueError:
                raise ValueError('Date must be in YYYY-MM-DD format')
        return v

class WeatherSearchResponse(WeatherSearchBase):
    id: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    weather_data: Optional[Any] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class CurrentWeatherResponse(BaseModel):
    location: str
    temperature: float
    feels_like: float
    condition: str
    humidity: int
    wind_speed: float
    wind_direction: str
    pressure: int
    visibility: float
    icon: str
    latitude: float
    longitude: float

class ForecastDay(BaseModel):
    day: str
    date: str
    high: float
    low: float
    condition: str
    icon: str

class ForecastResponse(BaseModel):
    forecast: list[ForecastDay]
