# Weather Application Design Guidelines

## Design Approach

**Selected Approach:** Design System-Based (Material Design)

**Rationale:** This is a data-intensive utility application requiring clear information hierarchy, efficient data entry, and robust CRUD interfaces. Material Design provides excellent patterns for weather data visualization, form handling, and table-based record management.

**Key Principles:**
- Functionality and clarity over decorative elements
- Efficient data entry and retrieval workflows
- Clear visual hierarchy for weather information
- Accessible, responsive design for mobile and desktop use

---

## Typography

**Font Family:** 
- Primary: Roboto (via Google Fonts CDN)
- Monospace: Roboto Mono (for coordinates, data values)

**Hierarchy:**
- App Title: text-2xl font-medium
- Section Headers: text-xl font-medium
- Weather Temperature (Primary): text-6xl font-bold
- Weather Temperature (Forecast): text-3xl font-semibold
- Location Name: text-3xl font-normal
- Body Text/Labels: text-base font-normal
- Secondary Info (humidity, wind): text-sm font-normal
- Form Labels: text-sm font-medium
- Table Headers: text-xs font-semibold uppercase tracking-wider
- Button Text: text-sm font-medium

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, and 16 consistently throughout.
- Component padding: p-4 to p-6
- Section spacing: mb-8 to mb-12
- Card padding: p-6
- Form field gaps: gap-4
- Grid gaps: gap-6

**Container Strategy:**
- Max width: max-w-6xl mx-auto
- Main padding: px-4 md:px-6 lg:px-8
- Vertical spacing: py-8 to py-12

---

## Component Library

### A. Header/Navigation
- Fixed top navigation bar with app title
- Includes geolocation quick-access button (with icon from Material Icons)
- Responsive: Collapses to mobile menu on small screens

### B. Search/Input Section
**Location Input Component:**
- Large search input with rounded corners (rounded-lg)
- Placeholder: "Enter city, zip code, coordinates, or landmark..."
- Search button (primary) adjacent to input
- Below input: Small helper text explaining accepted formats
- Current location button with GPS icon (separate from main search)

### C. Current Weather Display
**Primary Weather Card:**
- Large card (shadow-lg rounded-xl) with generous padding (p-8)
- Layout: Two-column on desktop (md:grid-cols-2), single on mobile
- Left column: Weather icon (large, 120x120px), current temperature, condition description
- Right column: Grid of weather details (2x2):
  - Feels Like temperature
  - Humidity percentage
  - Wind speed and direction
  - Pressure
- Each detail in its own mini-card or section with icon + label + value
- Location name prominently displayed above card

### D. 5-Day Forecast
**Forecast Cards Grid:**
- Grid layout: grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4
- Each day card contains:
  - Day of week (text-sm font-semibold)
  - Weather icon (64x64px)
  - High/Low temperatures (text-lg)
  - Brief condition text (text-xs)
- Cards with hover effect (subtle scale or shadow change)

### E. CRUD Interface Section
**Saved Searches Management:**
- Section header with "Saved Weather Searches" title
- "Add New Search" button (primary action button)

**Table/List Display (READ):**
- Responsive table for desktop: columns for Location, Date Range, Temperature, Actions
- Card layout for mobile (stack each record)
- Each row includes: Edit button, Delete button (icon buttons)
- Empty state message when no records exist

**Create/Update Form (Modal or Inline):**
- Form fields in vertical stack (space-y-4):
  - Location input (text field)
  - Start date picker
  - End date picker
  - Temperature display (auto-populated, read-only)
- Validation messages below each field
- Action buttons: Save (primary), Cancel (secondary)
- Form appears in modal overlay (backdrop blur) or expandable panel

**Delete Confirmation:**
- Simple modal with warning message
- Confirm (danger button) and Cancel buttons

### F. Optional Features (API Integrations)
**Map Integration Section:**
- Embedded map card (h-64 to h-96)
- Displays location marker
- Appears below current weather when location is specific

**YouTube Videos Section:**
- Horizontal scrollable list of video thumbnails
- Each thumbnail: 16:9 aspect ratio, 200px wide
- Click to play in modal or navigate to YouTube

**Export Controls:**
- Dropdown or button group for export format selection (JSON, CSV, PDF, XML, Markdown)
- Export button with download icon
- Positioned in CRUD section header area

### G. Form Elements
**Text Inputs:**
- Height: h-12
- Padding: px-4
- Border: border rounded-lg
- Focus ring: focus:ring-2 focus:ring-offset-2

**Buttons:**
- Primary: Solid background, rounded-lg, px-6 py-3
- Secondary: Outlined style, same sizing
- Icon buttons: Circular (w-10 h-10), icon centered
- All buttons: font-medium text-sm

**Date Pickers:**
- Native HTML5 date inputs styled to match design
- Fallback: Custom calendar widget with Material Design patterns

### H. Icons
**Icon Library:** Material Icons (via CDN)
- Weather condition icons (cloud, sun, rain, etc.)
- UI action icons (search, location, edit, delete, download)
- Navigation icons (menu, close)

**Icon Sizes:**
- Navigation/UI: 24px
- Weather (current): 120px
- Weather (forecast): 64px
- Action buttons: 20px

### I. Cards & Containers
**Card Styling:**
- Rounded corners: rounded-xl
- Shadow: shadow-md (default), shadow-lg (elevated)
- Background: Solid panel background
- Border: Optional subtle border

**Card Hover States:**
- Interactive cards: scale-105 transition on hover
- Subtle shadow increase

---

## Responsive Behavior

**Breakpoints:**
- Mobile: Default (< 640px)
- Tablet: md (≥ 768px)
- Desktop: lg (≥ 1024px)

**Key Responsive Patterns:**
- Search input: Full width on mobile, max-w-xl on desktop
- Current weather: Stack on mobile, 2-column on md+
- Forecast: 2 cards on mobile, 3 on tablet, 5 on desktop
- CRUD table: Card layout on mobile, table on md+
- Navigation: Hamburger menu on mobile, horizontal on desktop

---

## Animations

Use sparingly and only for functional feedback:
- Page transitions: Simple fade-in (opacity change, 200ms)
- Loading states: Spinner for API calls
- Form validation: Shake animation for errors (subtle)
- Card hover: Transform scale (100ms)
- Modal entry/exit: Fade + scale (150ms)

**No decorative animations.** Focus on instant feedback for user actions.

---

## Images

**Weather Condition Icons:**
- Use icon library (Material Icons or weather-specific icon set like Weather Icons by Erik Flowers)
- Placement: Center of current weather card, smaller versions in forecast cards
- Style: Simplified, clear iconography

**No hero images** - This is a utility application focused on data and functionality.

---

## Accessibility

- All form inputs have visible labels
- Icon buttons include aria-labels
- Color contrast meets WCAG AA standards
- Keyboard navigation fully supported
- Focus indicators clearly visible
- Error messages associated with form fields
- Table headers properly marked up